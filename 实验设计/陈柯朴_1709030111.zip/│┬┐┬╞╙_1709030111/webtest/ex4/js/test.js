function test(){
	var a = "";
	for(let r=0;r<10;r++){
		a = a+" "+r;
		console.log(a)
	}
}

