# 实训展示
- 1.index.html 主页
- 2.左侧菜单栏展示
- 3.在进去网页展示模式时，加入动画效果
- 4.所有的实训上传至服务器

# focusinfo
# 头像
# 课程名字
# 联系方式
# iframeisshow
# iframe框架
# 1.点击主页 focusinfo显示  iframeisshow不显示
# 2.点击实训 focusinfo不显示  iframeisshow显示